// Scene সেটআপ
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();

renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// গ্রাউন্ড তৈরি
const groundGeometry = new THREE.PlaneGeometry(20, 50);
const groundMaterial = new THREE.MeshBasicMaterial({ color: 0x228B22 });
const ground = new THREE.Mesh(groundGeometry, groundMaterial);
ground.rotation.x = -Math.PI / 2;
scene.add(ground);

// মব তৈরি
const mobGeometry = new THREE.SphereGeometry(0.5, 16, 16);
const mobMaterial = new THREE.MeshBasicMaterial({ color: 0x0000ff });
const mobs = [];

for (let i = 0; i < 5; i++) {
    let mob = new THREE.Mesh(mobGeometry, mobMaterial);
    mob.position.set(-2 + i, 0.5, -20);
    scene.add(mob);
    mobs.push(mob);
}

// ক্যামেরা সেটআপ
camera.position.set(0, 5, 5);
camera.lookAt(0, 0, -10);

// মব মুভমেন্ট আপডেট ফাংশন
function animate() {
    requestAnimationFrame(animate);
    mobs.forEach(mob => { mob.position.z += 0.05; });
    renderer.render(scene, camera);
}

animate();